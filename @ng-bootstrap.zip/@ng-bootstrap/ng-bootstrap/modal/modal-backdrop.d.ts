export declare class NgbModalBackdrop {
    backdropClass: string;
}
