export { NgbAlert } from './alert';
export { NgbAlertConfig } from './alert-config';
export declare class NgbAlertModule {
}
