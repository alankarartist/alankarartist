export { NgbToast, NgbToastHeader } from './toast';
export { NgbToastConfig, NgbToastOptions } from './toast-config';
export declare class NgbToastModule {
}
