export { NgbProgressbar } from './progressbar';
export { NgbProgressbarConfig } from './progressbar-config';
export declare class NgbProgressbarModule {
}
