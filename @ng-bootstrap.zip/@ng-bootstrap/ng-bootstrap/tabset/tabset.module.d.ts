export { NgbTabset, NgbTab, NgbTabContent, NgbTabTitle, NgbTabChangeEvent } from './tabset';
export { NgbTabsetConfig } from './tabset-config';
export declare class NgbTabsetModule {
}
