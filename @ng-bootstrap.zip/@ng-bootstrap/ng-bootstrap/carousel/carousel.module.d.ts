export { NgbCarousel, NgbSlide, NgbSlideEvent, NgbSlideEventDirection, NgbSlideEventSource } from './carousel';
export { NgbCarouselConfig } from './carousel-config';
export declare class NgbCarouselModule {
}
