export { NgbAccordion, NgbPanel, NgbPanelTitle, NgbPanelContent, NgbPanelChangeEvent, NgbPanelHeader, NgbPanelHeaderContext, NgbPanelToggle } from './accordion';
export { NgbAccordionConfig } from './accordion-config';
export declare class NgbAccordionModule {
}
