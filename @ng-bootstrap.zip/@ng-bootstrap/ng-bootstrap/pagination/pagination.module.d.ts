export { NgbPagination, NgbPaginationEllipsis, NgbPaginationFirst, NgbPaginationLast, NgbPaginationNext, NgbPaginationNumber, NgbPaginationPrevious } from './pagination';
export { NgbPaginationConfig } from './pagination-config';
export declare class NgbPaginationModule {
}
