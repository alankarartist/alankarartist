export { NgbCollapse } from './collapse';
export declare class NgbCollapseModule {
}
