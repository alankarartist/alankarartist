export { NgbPopover } from './popover';
export { NgbPopoverConfig } from './popover-config';
export { Placement } from '../util/positioning';
export declare class NgbPopoverModule {
}
